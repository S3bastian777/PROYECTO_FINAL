import React, { useEffect, useMemo, useState } from 'react';
import './App.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';
const money = v => new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(Number(v||0));
const today = new Date();
const currentMonth = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}`;

function session(){try{return JSON.parse(localStorage.getItem('moneytrack_user')||'null')}catch{return null}}

async function request(path,options={}){
  const u=session();
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  if(u){headers['X-User-Id']=u.id;headers['X-User-Role']=u.role}
  const r=await fetch(API+path,{...options,headers});
  let data=null; try{data=await r.json()}catch{}
  if(!r.ok)throw new Error(data?.message||`Error HTTP ${r.status}`);
  return data;
}

function TableWrap({children}){return <div className="table-wrap">{children}</div>}

function Auth({onLogin}){
  const [mode,setMode]=useState('login');
  const [form,setForm]=useState({nombre:'',email:'',password:'',code:'',newPassword:''});
  const [error,setError]=useState(''),[ok,setOk]=useState(''),[loading,setLoading]=useState(false);
  useEffect(()=>{setError('');setOk('')},[mode]);
  const submit=async e=>{
    e.preventDefault();setError('');setOk('');setLoading(true);
    try{
      if(mode==='login'){
        const data=await request('/auth/login',{method:'POST',body:JSON.stringify({email:form.email,password:form.password})});
        localStorage.setItem('moneytrack_user',JSON.stringify(data));onLogin(data);
      }else if(mode==='register'){
        await request('/auth/register',{method:'POST',body:JSON.stringify({nombre:form.nombre,correo:form.email,clave:form.password,rol:'cliente'})});
        setMode('login');setOk('Cuenta creada correctamente. Revisa tu correo si tienes confirmación habilitada.');
      }else if(mode==='forgot'){
        await request('/auth/forgot-password',{method:'POST',body:JSON.stringify({email:form.email})});
        setMode('verify');setOk('Código de 6 dígitos enviado a tu correo.');
      }else{
        await request('/auth/reset-password',{method:'POST',body:JSON.stringify({email:form.email,code:form.code,newPassword:form.newPassword})});
        setMode('login');setOk('Contraseña actualizada con éxito. Inicia sesión.');
      }
    }catch(e){setError(e.message)}finally{setLoading(false)}
  };
  return <main className="auth-page">
    <section className="auth-card">
      <div className="brand">MT</div><p className="eyebrow">MONEY TRACK</p>
      <h1>{mode==='login'?'Iniciar sesión':mode==='register'?'Crear cuenta':mode==='forgot'?'Recuperar contraseña':'Restablecer contraseña'}</h1>
      <p className="subtitle">{mode==='login'?'Tu centro de control financiero personal.':mode==='register'?'Crea tu espacio para organizar ingresos y gastos.':mode==='forgot'?'Recibe un código temporal en tu correo.':'Ingresa el código recibido y define una nueva clave.'}</p>
      {error&&<div className="alerta">{error}</div>}{ok&&<div className="alerta ok">{ok}</div>}
      <form onSubmit={submit}>
        {mode==='register'&&<><label>Nombre</label><input value={form.nombre} onChange={e=>setForm({...form,nombre:e.target.value})} placeholder="Tu nombre" required/></>}
        <label>Correo electrónico</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="correo@ejemplo.com" required disabled={mode==='verify'}/>
        {(mode==='login'||mode==='register')&&<><label>Contraseña</label><input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="Tu contraseña" minLength="6" required/></>}
        {mode==='verify'&&<><label>Código de confirmación</label><input inputMode="numeric" maxLength="6" value={form.code} onChange={e=>setForm({...form,code:e.target.value.replace(/\D/g,'')})} placeholder="123456" required/><label>Nueva contraseña</label><input type="password" minLength="6" value={form.newPassword} onChange={e=>setForm({...form,newPassword:e.target.value})} placeholder="Nueva contraseña" required/></>}
        <button className="primary auth-submit" disabled={loading}>{loading?'Procesando...':mode==='login'?'Ingresar':mode==='register'?'Crear cuenta':mode==='forgot'?'Enviar código':'Cambiar contraseña'}</button>
      </form>
      <div className="switch">
        {mode==='login'?<><button type="button" onClick={()=>setMode('forgot')}>¿Olvidaste tu contraseña?</button><span>·</span><button type="button" onClick={()=>setMode('register')}>Crear cuenta</button></>:<button type="button" onClick={()=>setMode('login')}>Volver al inicio de sesión</button>}
      </div>
    </section>
  </main>
}

function Dashboard({me,onLogout}){
  const [activeTab,setActiveTab]=useState('inicio');
  const [data,setData]=useState({usuarios:[],saldos:[],gastos:[],reportes:[],categorias:{predefinidas:[],fijas:[],inusuales:[],ingresos:[]}});
  const [error,setError]=useState(''),[ok,setOk]=useState(''),[loading,setLoading]=useState(true);
  const [mov,setMov]=useState({userId:'',valor:'',categoria:'Mercado',medioPago:'Efectivo',descripcion:'',tipoMovimiento:'GASTO',tipoGasto:'PREDEFINIDO',recurrente:false});
  const [editMov,setEditMov]=useState(null),[editUser,setEditUser]=useState(null);
  const [reportMonth,setReportMonth]=useState(currentMonth),[reportUser,setReportUser]=useState('');
  const [catType,setCatType]=useState('PREDEFINIDO'),[catName,setCatName]=useState('');
  const metasKey=`moneytrack_metas_${me.id}`;
  const [metas,setMetas]=useState(()=>{try{return JSON.parse(localStorage.getItem(metasKey)||'[]')}catch{return[]}});
  const [nuevaMeta,setNuevaMeta]=useState({titulo:'',objetivo:'',fecha:'',imagen:''});

  const load=async()=>{setLoading(true);try{setData(await request('/dashboard'));setError('')}catch(e){setError(e.message)}finally{setLoading(false)}};
  useEffect(()=>{load()},[]);
  useEffect(()=>{localStorage.setItem(metasKey,JSON.stringify(metas))},[metas,metasKey]);
  const users=data.usuarios||[];
  const cats=data.categorias||{};
  const gastos=data.gastos||[];
  const monthGastos=useMemo(()=>gastos.filter(g=>String(g.createdAt||'').slice(0,7)===currentMonth),[gastos]);
  const totalMetasApartado=useMemo(()=>metas.reduce((a,m)=>a+Number(m.ahorrado||0),0),[metas]);
  const totals=useMemo(()=>{
    const ingresos=monthGastos.filter(g=>g.tipoMovimiento==='INGRESO').reduce((a,g)=>a+Number(g.valor||0),0);
    const egresos=monthGastos.filter(g=>g.tipoMovimiento!=='INGRESO').reduce((a,g)=>a+Number(g.valor||0),0);
    const saldoReal=me.role==='admin'?(data.saldos||[]).reduce((a,s)=>a+Number(s.saldoActual||0),0):Number(data.saldos?.[0]?.saldoActual||0);
    const saldo=Math.max(0,saldoReal-totalMetasApartado);
    return {ingresos,egresos,saldo,saldoReal};
  },[monthGastos,data.saldos,me.role,totalMetasApartado]);

  const categoryOptions=mov.tipoMovimiento==='INGRESO'?cats.ingresos||[]:mov.tipoGasto==='FIJO'?cats.fijas||[]:mov.tipoGasto==='INUSUAL'?cats.inusuales||[]:cats.predefinidas||[];
  useEffect(()=>{if(categoryOptions.length&&!categoryOptions.includes(mov.categoria))setMov(x=>({...x,categoria:categoryOptions[0]}))},[mov.tipoMovimiento,mov.tipoGasto,cats.predefinidas,cats.fijas,cats.inusuales,cats.ingresos]);

  const resetMov=()=>setMov({userId:'',valor:'',categoria:'Mercado',medioPago:'Efectivo',descripcion:'',tipoMovimiento:'GASTO',tipoGasto:'PREDEFINIDO',recurrente:false});
  const saveMov=async e=>{e.preventDefault();try{
    const valor=Number(mov.valor);
    if(!Number.isFinite(valor)||valor<=0)throw new Error('Ingresa un valor mayor que 0.');
    const body={userId:me.role==='admin'?(mov.userId||null):null,valor,categoria:mov.categoria,medioPago:mov.medioPago,descripcion:mov.descripcion,tipoMovimiento:mov.tipoMovimiento,tipoGasto:mov.tipoGasto,recurrente:mov.recurrente};
    await request(editMov?`/gastos/${editMov.id}`:'/gastos',{method:editMov?'PUT':'POST',body:JSON.stringify(body)});
    setOk(editMov?'Movimiento actualizado correctamente.':'Movimiento registrado correctamente.');setEditMov(null);resetMov();await load();
  }catch(e){setError(e.message)}};
  const delMov=async id=>{if(!window.confirm('¿Eliminar este movimiento?'))return;try{await request(`/gastos/${id}`,{method:'DELETE'});setOk('Movimiento eliminado.');await load()}catch(e){setError(e.message)}};
  const startEdit=g=>{setEditMov(g);setMov({userId:g.userId||'',valor:g.valor,categoria:g.categoria,medioPago:g.medioPago,descripcion:g.descripcion,tipoMovimiento:g.tipoMovimiento||'GASTO',tipoGasto:g.tipoGasto||'PREDEFINIDO',recurrente:!!g.recurrente});setActiveTab('movimientos')};
  const updateUser=async e=>{e.preventDefault();try{await request(`/admin/usuarios/${editUser.id}`,{method:'PUT',body:JSON.stringify(editUser)});setOk('Usuario actualizado.');setEditUser(null);await load()}catch(e){setError(e.message)}};
  const delUser=async id=>{if(!window.confirm('¿Eliminar este usuario?'))return;try{await request(`/admin/usuarios/${id}`,{method:'DELETE'});setOk('Usuario eliminado.');await load()}catch(e){setError(e.message)}};
  const addCat=async e=>{e.preventDefault();if(!catName.trim())return;try{await request('/categorias',{method:'POST',body:JSON.stringify({tipo:catType,nombre:catName.trim()})});setCatName('');setOk('Categoría guardada en tu cuenta.');await load()}catch(e){setError(e.message)}};
  const delCat=async(name)=>{if(!window.confirm(`¿Eliminar la categoría "${name}"?`))return;try{await request(`/categorias?tipo=${encodeURIComponent(catType)}&nombre=${encodeURIComponent(name)}`,{method:'DELETE'});setOk('Categoría eliminada.');await load()}catch(e){setError(e.message)}};
  const downloadCertificate=async()=>{
    try{
      const u=session();const qs=new URLSearchParams({month:reportMonth});if(me.role==='admin'&&reportUser)qs.set('targetUser',reportUser);
      const r=await fetch(`${API}/reportes/certificado?${qs}`,{headers:{'X-User-Id':u.id,'X-User-Role':u.role}});
      if(!r.ok)throw new Error('No fue posible generar el certificado.');
      const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`moneytrack-${reportMonth}.pdf`;a.click();URL.revokeObjectURL(url);setOk('Certificado mensual descargado.');
    }catch(e){setError(e.message)}
  };

  const reportRows=useMemo(()=>{
    const selectedUser=me.role==='admin'&&reportUser?Number(reportUser):me.id;
    const list=gastos.filter(g=>Number(g.userId)===Number(selectedUser)&&String(g.createdAt||'').slice(0,7)===reportMonth);
    const previousDate=new Date(`${reportMonth}-01T00:00:00`);
    previousDate.setMonth(previousDate.getMonth()-1);
    const previousMonth=`${previousDate.getFullYear()}-${String(previousDate.getMonth()+1).padStart(2,'0')}`;
    const previous=gastos.filter(g=>Number(g.userId)===Number(selectedUser)&&String(g.createdAt||'').slice(0,7)===previousMonth&&g.tipoMovimiento==='GASTO').reduce((a,g)=>a+Number(g.valor),0);
    const income=list.filter(g=>g.tipoMovimiento==='INGRESO').reduce((a,g)=>a+Number(g.valor),0);
    const fixed=list.filter(g=>g.tipoMovimiento==='GASTO'&&g.tipoGasto==='FIJO').reduce((a,g)=>a+Number(g.valor),0);
    const unusual=list.filter(g=>g.tipoMovimiento==='GASTO'&&g.tipoGasto==='INUSUAL').reduce((a,g)=>a+Number(g.valor),0);
    const predefined=list.filter(g=>g.tipoMovimiento==='GASTO'&&g.tipoGasto==='PREDEFINIDO').reduce((a,g)=>a+Number(g.valor),0);
    return {list,income,fixed,unusual,predefined,total:fixed+unusual+predefined,previous,previousMonth};
  },[gastos,reportMonth,reportUser,me.id,me.role]);

  const addMeta=e=>{e.preventDefault();if(!nuevaMeta.titulo||!nuevaMeta.objetivo)return;setMetas([...metas,{...nuevaMeta,id:Date.now(),ahorrado:0}]);setNuevaMeta({titulo:'',objetivo:'',fecha:'',imagen:''});setOk('Meta creada.')};
  const addAporte=(id,val)=>{
    const n=Number(val||0);
    const meta=metas.find(m=>m.id===id);
    const disponible=Math.max(0,totals.saldo);
    if(!meta||!Number.isFinite(n)||n<=0){setError('Ingresa un aporte válido.');return;}
    const restante=Math.max(0,Number(meta.objetivo||0)-Number(meta.ahorrado||0));
    if(n>restante){setError(`El aporte supera lo que falta para completar la meta (${money(restante)}).`);return;}
    if(n>disponible){setError(`No tienes suficiente saldo disponible. Disponible: ${money(disponible)}.`);return;}
    setMetas(metas.map(m=>m.id===id?{...m,ahorrado:Number(m.ahorrado||0)+n,aporte:''}:m));
    setOk(`Aporte de ${money(n)} apartado para ${meta.titulo}.`);
  };
  const deleteMeta=id=>{if(window.confirm('¿Eliminar esta meta?'))setMetas(metas.filter(m=>m.id!==id))};
  const handleMetaImage=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>setNuevaMeta(m=>({...m,imagen:r.result}));r.readAsDataURL(f)};

  const nav=[
    ['inicio','⌂','Resumen'],
    ['movimientos','↕','Movimientos'],
    ['metas','◎','Metas de ahorro'],
    ['reportes','▥','Reportes'],
    ['categorias','#','Categorías'],
    ...(me.role==='admin'?[['usuarios','♙','Usuarios']]:[])
  ];

  return <div className="app-layout">
    <aside className="sidebar">
      <div className="sidebar-brand"><div className="logo-mini">MT</div><div><b>Money Track</b><small>Control financiero</small></div></div>
      <div className="profile-mini"><div className="avatar">{(me.name||'U').charAt(0).toUpperCase()}</div><div><strong>{me.name}</strong><span>{me.role==='admin'?'Administrador':'Cliente'}</span></div></div>
      <nav className="sidebar-nav">{nav.map(([id,icon,label])=><button key={id} className={activeTab===id?'active':''} onClick={()=>setActiveTab(id)}><span>{icon}</span>{label}</button>)}</nav>
      <div className="sidebar-footer"><button className="btn-logout" onClick={onLogout}>↪ Cerrar sesión</button></div>
    </aside>

    <div className="main-content">
      <header className="top-bar">
        <div><p className="eyebrow">PANEL FINANCIERO</p><h2>{activeTab==='inicio'?'Resumen general':nav.find(x=>x[0]===activeTab)?.[2]}</h2><span className="date-line">Hoy · {new Date().toLocaleDateString('es-CO',{weekday:'long',day:'numeric',month:'long'})}</span></div>
        <button className="quick-btn" onClick={()=>{setActiveTab('movimientos');resetMov()}}>＋ Nuevo movimiento</button>
      </header>

      <main className="content-body">
        {ok&&<div className="alerta ok">{ok}<button onClick={()=>setOk('')}>×</button></div>}
        {error&&<div className="alerta">{error}<button onClick={()=>setError('')}>×</button></div>}
        {loading?<div className="card loading"><div className="spinner"/>Cargando tu información...</div>:<>
          {activeTab==='inicio'&&<div className="fade-in">
            <section className="hero-card"><div><span className="hero-kicker">TU SALUD FINANCIERA</span><h1>Hola, {me.name?.split(' ')[0]} 👋</h1><p>Revisa lo que entró, lo que salió y cuánto tienes disponible este mes.</p></div><div className="hero-month"><span>Mes actual</span><b>{new Date().toLocaleDateString('es-CO',{month:'long',year:'numeric'})}</b></div></section>
            <section className="stats-grid">
              <article className="stat-card"><div className="stat-icon income">↗</div><span>Ingresos del mes</span><strong>{money(totals.ingresos)}</strong><small>Entradas registradas</small></article>
              <article className="stat-card"><div className="stat-icon expense">↘</div><span>Gastos del mes</span><strong>{money(totals.egresos)}</strong><small>Salidas registradas</small></article>
              <article className="stat-card"><div className="stat-icon balance">◈</div><span>Saldo disponible</span><strong>{money(totals.saldo)}</strong><small>Saldo actual</small></article>
              <article className="stat-card"><div className="stat-icon save">★</div><span>Balance mensual</span><strong>{money(totals.ingresos-totals.egresos)}</strong><small>{totals.ingresos>=totals.egresos?'Resultado positivo':'Revisa tus egresos'}</small></article>
            </section>
            <section>
              <article className="card"><div className="section-head"><div><p className="eyebrow">ÚLTIMOS REGISTROS</p><h2>Actividad reciente</h2></div><button className="text-btn" onClick={()=>setActiveTab('movimientos')}>Ver todos →</button></div>
                <div className="mini-list">{gastos.slice(0,5).map(g=><div className="mini-row" key={g.id}><div className={`mini-icon ${g.tipoMovimiento==='INGRESO'?'income':'expense'}`}>{g.tipoMovimiento==='INGRESO'?'↗':'↘'}</div><div className="mini-main"><strong>{g.categoria}</strong><span>{g.descripcion}</span></div><b className={g.tipoMovimiento==='INGRESO'?'positive':''}>{g.tipoMovimiento==='INGRESO'?'+':'-'}{money(g.valor)}</b></div>)}{!gastos.length&&<div className="empty-state">Aún no hay movimientos.</div>}</div>
              </article>
            </section>
          </div>}

          {activeTab==='movimientos'&&<section className="fade-in">
            <div className="section-title"><div><p className="eyebrow">REGISTROS</p><h1>{editMov?'Editar movimiento':'Nuevo movimiento'}</h1><p>Separa tus ingresos de los gastos y clasifica cada salida.</p></div></div>
            <div className="grid2">
              <article className="card form-card">
                <div className="segmented"><button className={mov.tipoMovimiento==='GASTO'?'selected':''} onClick={()=>setMov({...mov,tipoMovimiento:'GASTO',tipoGasto:'PREDEFINIDO'})} type="button">↘ Gasto</button><button className={mov.tipoMovimiento==='INGRESO'?'selected income-selected':''} onClick={()=>setMov({...mov,tipoMovimiento:'INGRESO',tipoGasto:'INGRESO'})} type="button">↗ Ingreso</button></div>
                <form onSubmit={saveMov}>
                  {me.role==='admin'&&<><label>Usuario</label><select value={mov.userId} onChange={e=>setMov({...mov,userId:e.target.value})} required><option value="">Selecciona un usuario</option>{users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></>}
                  {mov.tipoMovimiento==='GASTO'&&<><label>Tipo de gasto</label><div className="type-grid">{[['PREDEFINIDO','General'],['FIJO','Fijo / recurrente'],['INUSUAL','Inusual']].map(([v,l])=><button type="button" key={v} className={mov.tipoGasto===v?'type-chip active':''} onClick={()=>setMov({...mov,tipoGasto:v,categoria:''})}>{l}</button>)}</div></>}
                  <label>Categoría</label><select value={mov.categoria} onChange={e=>setMov({...mov,categoria:e.target.value})} required>{categoryOptions.map(c=><option key={c}>{c}</option>)}</select>
                  <label>Valor</label><input type="number" min="1" step="1" value={mov.valor} onChange={e=>setMov({...mov,valor:e.target.value})} placeholder="0" required/>
                  <label>Medio de pago</label><select value={mov.medioPago} onChange={e=>setMov({...mov,medioPago:e.target.value})}><option>Efectivo</option><option>Nequi</option><option>Daviplata</option><option>Bancolombia</option><option>Tarjeta débito</option><option>Tarjeta crédito</option><option>Transferencia</option><option>Otro</option></select>
                  <label>Descripción</label><input maxLength="160" value={mov.descripcion} onChange={e=>setMov({...mov,descripcion:e.target.value})} placeholder="Ej. Arriendo septiembre" required/>
                  {mov.tipoMovimiento==='GASTO'&&mov.tipoGasto==='FIJO'&&<label className="check-row"><input type="checkbox" checked={mov.recurrente} onChange={e=>setMov({...mov,recurrente:e.target.checked})}/><span><b>Hacer recurrente</b><small>Se registrará automáticamente cada mes cuando haya saldo suficiente.</small></span></label>}
                  <div className="actions"><button className="primary">{editMov?'Guardar cambios':'Registrar movimiento'}</button>{editMov&&<button type="button" className="secondary" onClick={()=>{setEditMov(null);resetMov()}}>Cancelar</button>}</div>
                </form>
              </article>
              <article className="card"><div className="section-head"><div><p className="eyebrow">HISTORIAL</p><h2>Todos los movimientos</h2></div><span className="count-badge">{gastos.length}</span></div><TableWrap><table><thead><tr>{me.role==='admin'&&<th>Usuario</th>}<th>Tipo</th><th>Categoría</th><th>Detalle</th><th>Valor</th><th>Fecha</th><th></th></tr></thead><tbody>{gastos.map(g=><tr key={g.id}>{me.role==='admin'&&<td>{g.userName||g.user?.name}</td>}<td><span className={`pill ${g.tipoMovimiento==='INGRESO'?'pill-income':'pill-expense'}`}>{g.tipoMovimiento==='INGRESO'?'Ingreso':g.tipoGasto==='FIJO'?'Fijo':g.tipoGasto==='INUSUAL'?'Inusual':'General'}</span></td><td><b>{g.categoria}</b>{g.recurrente&&<small className="recurring">↻ Recurrente</small>}</td><td>{g.descripcion}<small className="muted">{g.medioPago}</small></td><td className={g.tipoMovimiento==='INGRESO'?'positive':''}>{g.tipoMovimiento==='INGRESO'?'+':'-'}{money(g.valor)}</td><td>{new Date(g.createdAt).toLocaleDateString('es-CO')}</td><td className="actions"><button className="small" onClick={()=>startEdit(g)}>Editar</button><button className="danger small" onClick={()=>delMov(g.id)}>Eliminar</button></td></tr>)}</tbody></table></TableWrap></article>
            </div>
          </section>}

          {activeTab==='metas'&&<div className="metas-layout fade-in"><article className="card meta-form-card"><p className="eyebrow">PLANIFICA</p><h2>Nueva meta</h2><form onSubmit={addMeta}><label>Nombre de la meta</label><input value={nuevaMeta.titulo} onChange={e=>setNuevaMeta({...nuevaMeta,titulo:e.target.value})} placeholder="Ej. Laptop, viaje..." required/><label>Monto objetivo</label><input type="number" min="1" step="1" value={nuevaMeta.objetivo} onChange={e=>setNuevaMeta({...nuevaMeta,objetivo:e.target.value})} required/><label>Fecha límite</label><input type="date" value={nuevaMeta.fecha} onChange={e=>setNuevaMeta({...nuevaMeta,fecha:e.target.value})}/><label>Imagen (opcional)</label><input type="url" placeholder="URL de imagen" value={nuevaMeta.imagen.startsWith('data:')?'':nuevaMeta.imagen} onChange={e=>setNuevaMeta({...nuevaMeta,imagen:e.target.value})}/><input type="file" accept="image/*" onChange={handleMetaImage}/>{nuevaMeta.imagen&&<img className="meta-preview" src={nuevaMeta.imagen} alt="Vista previa"/>}<button className="primary">Crear meta</button></form></article><article className="card"><div className="section-head"><div><p className="eyebrow">OBJETIVOS</p><h2>Tus metas</h2><small className="muted">Saldo disponible después de apartar metas: <b>{money(totals.saldo)}</b></small></div></div>{!metas.length?<p className="empty-state">Crea tu primera meta de ahorro.</p>:<div className="goal-list">{metas.map(m=>{const p=Math.min(100,Math.round(Number(m.ahorrado||0)/Number(m.objetivo||1)*100));return <div className="goal-card" key={m.id}>{m.imagen?<img src={m.imagen} alt={m.titulo}/>:<div className="goal-fallback">MT</div>}<div><div className="section-head"><h3>{m.titulo}</h3><button className="danger small" onClick={()=>deleteMeta(m.id)}>Eliminar</button></div><p>{money(m.ahorrado)} de {money(m.objetivo)}</p><div className="progress"><span style={{width:`${p}%`}}/></div><div className="goal-footer"><span>{p}% completado</span><span>{m.fecha||'Sin fecha límite'}</span></div><div className="inline"><input type="number" min="1" step="1" placeholder="Aporte" value={m.aporte||''} onChange={e=>setMetas(metas.map(x=>x.id===m.id?{...x,aporte:e.target.value}:x))}/><button className="small" onClick={()=>addAporte(m.id,m.aporte)}>Sumar</button></div></div></div>})}</div>}</article></div>}

          {activeTab==='reportes'&&<section className="fade-in"><div className="section-title"><div><p className="eyebrow">ANÁLISIS</p><h1>Reporte mensual</h1><p>Consulta la distribución de ingresos y gastos y descarga un certificado.</p></div><div className="report-filters"><label>Mes<input type="month" value={reportMonth} onChange={e=>setReportMonth(e.target.value)}/></label>{me.role==='admin'&&<label>Usuario<select value={reportUser} onChange={e=>setReportUser(e.target.value)}><option value="">Seleccionar usuario</option>{users.map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label>}<button className="primary" onClick={downloadCertificate}>↓ Descargar certificado PDF</button></div></div>
            <section className="stats-grid report-stats"><article className="stat-card"><span>Ingresos</span><strong>{money(reportRows.income)}</strong></article><article className="stat-card"><span>Gastos fijos</span><strong>{money(reportRows.fixed)}</strong></article><article className="stat-card"><span>Gastos inusuales</span><strong>{money(reportRows.unusual)}</strong></article><article className="stat-card"><span>Gastos generales</span><strong>{money(reportRows.predefined)}</strong></article></section>
            <article className="card comparison-card"><div className="section-head"><div><p className="eyebrow">COMPARATIVO</p><h2>Este mes vs. mes anterior</h2></div><span className={reportRows.total<=reportRows.previous?'comparison-good':'comparison-bad'}>{reportRows.total<=reportRows.previous?'↓ Menor gasto':'↑ Mayor gasto'}</span></div><div className="compare-grid"><div><span>{reportMonth}</span><b>{money(reportRows.total)}</b></div><div><span>{reportRows.previousMonth}</span><b>{money(reportRows.previous)}</b></div><div><span>Diferencia</span><b>{money(Math.abs(reportRows.total-reportRows.previous))}</b></div></div></article>
            <div className="grid2"><article className="card"><div className="section-head"><div><p className="eyebrow">DISTRIBUCIÓN</p><h2>Gastos por división</h2></div><strong>{money(reportRows.total)}</strong></div><div className="bars"><div className="bar-row"><span>Generales</span><div><i style={{width:`${reportRows.total?reportRows.predefined/reportRows.total*100:0}%`}}/></div><b>{money(reportRows.predefined)}</b></div><div className="bar-row"><span>Fijos</span><div><i style={{width:`${reportRows.total?reportRows.fixed/reportRows.total*100:0}%`}}/></div><b>{money(reportRows.fixed)}</b></div><div className="bar-row"><span>Inusuales</span><div><i style={{width:`${reportRows.total?reportRows.unusual/reportRows.total*100:0}%`}}/></div><b>{money(reportRows.unusual)}</b></div></div><div className="report-result"><span>Balance del mes</span><strong>{money(reportRows.income-reportRows.total)}</strong></div></article>
            <article className="card"><div className="section-head"><div><p className="eyebrow">DETALLE</p><h2>Movimientos del mes</h2></div><span className="count-badge">{reportRows.list.length}</span></div><TableWrap><table><thead><tr><th>Tipo</th><th>Categoría</th><th>Valor</th><th>Fecha</th></tr></thead><tbody>{reportRows.list.map(g=><tr key={g.id}><td>{g.tipoMovimiento==='INGRESO'?'Ingreso':g.tipoGasto}</td><td>{g.categoria}</td><td className={g.tipoMovimiento==='INGRESO'?'positive':''}>{g.tipoMovimiento==='INGRESO'?'+':'-'}{money(g.valor)}</td><td>{new Date(g.createdAt).toLocaleDateString('es-CO')}</td></tr>)}</tbody></table></TableWrap></article></div>
          </section>}

          {activeTab==='categorias'&&<section className="fade-in"><div className="section-title"><div><p className="eyebrow">PERSONALIZA</p><h1>Categorías</h1><p>Las categorías que crees quedan guardadas en tu cuenta y estarán disponibles en próximos registros.</p></div></div><div className="category-layout"><article className="card"><p className="eyebrow">NUEVA CATEGORÍA</p><h2>Agregar una categoría</h2><form onSubmit={addCat}><label>División</label><select value={catType} onChange={e=>setCatType(e.target.value)}><option value="PREDEFINIDO">Gasto general</option><option value="FIJO">Gasto fijo</option><option value="INUSUAL">Gasto inusual</option><option value="INGRESO">Ingreso</option></select><label>Nombre</label><input value={catName} onChange={e=>setCatName(e.target.value)} placeholder="Ej. Mensualidades app" maxLength="50" required/><button className="primary">Guardar categoría</button></form></article><div className="category-grid">{[['PREDEFINIDO','Gastos generales',cats.predefinidas||[]],['FIJO','Gastos fijos',cats.fijas||[]],['INUSUAL','Gastos inusuales',cats.inusuales||[]],['INGRESO','Ingresos',cats.ingresos||[]]].map(([type,title,list])=><article className="card category-card" key={type}><div className="section-head"><h2>{title}</h2><span>{list.length}</span></div><div className="tag-list">{list.map(c=><span key={c} className="category-tag">{c}{/* solo las personalizadas son eliminables */}{((type==='PREDEFINIDO'&&!(["Mercado","Transporte","Salud","Educación","Servicios","Vivienda","Alimentación","Entretenimiento","Ropa","Tecnología","Mascotas","Otro"].includes(c)))||(type==='FIJO'&&!["Arriendo","Servicios públicos","Internet","Telefonía","Suscripciones","Cuota de crédito","Seguros","Mensualidades app","Colegio/Universidad","Otro fijo"].includes(c))||(type==='INUSUAL'&&!["Reparaciones","Emergencias","Regalos","Multas","Viajes","Compras extraordinarias","Mantenimiento","Otro inusual"].includes(c))||(type==='INGRESO'&&!["Salario","Mesada","Freelance","Venta","Bono","Otros ingresos"].includes(c)))&&<button onClick={()=>{setCatType(type);delCat(c)}}>×</button>}</span>)}</div></article>)}</div></div></section>}

          {activeTab==='usuarios'&&me.role==='admin'&&<section className="card fade-in"><div className="section-head"><div><p className="eyebrow">ADMINISTRACIÓN</p><h1>Usuarios</h1></div><span className="count-badge">{users.length}</span></div><TableWrap><table><thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Acciones</th></tr></thead><tbody>{users.map(u=><tr key={u.id}>{editUser?.id===u.id?<td colSpan="4"><form className="user-edit" onSubmit={updateUser}><input value={editUser.name} onChange={e=>setEditUser({...editUser,name:e.target.value})}/><input value={editUser.username||''} onChange={e=>setEditUser({...editUser,username:e.target.value})}/><select value={editUser.role} onChange={e=>setEditUser({...editUser,role:e.target.value})}><option value="cliente">Cliente</option><option value="admin">Administrador</option></select><input type="password" value={editUser.password||''} onChange={e=>setEditUser({...editUser,password:e.target.value})} placeholder="Nueva clave (opcional)"/><button className="small">Guardar</button><button type="button" className="secondary small" onClick={()=>setEditUser(null)}>Cancelar</button></form></td>:<><td><b>{u.name}</b></td><td>{u.email||u.username}</td><td><span className="pill">{u.role}</span></td><td className="actions"><button className="small" onClick={()=>setEditUser({...u,password:''})}>Editar</button><button className="danger small" onClick={()=>delUser(u.id)}>Eliminar</button></td></>}</tr>)}</tbody></table></TableWrap></section>}
        </>}
      </main>
    </div>
  </div>
}

export default function App(){const [user,setUser]=useState(session());const logout=()=>{localStorage.removeItem('moneytrack_user');setUser(null)};return <div className="app">{user?<Dashboard me={user} onLogout={logout}/>:<Auth onLogin={setUser}/>}</div>}
