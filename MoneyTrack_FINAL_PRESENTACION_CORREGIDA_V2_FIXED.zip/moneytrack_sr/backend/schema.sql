CREATE DATABASE IF NOT EXISTS money_track CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE money_track;

CREATE TABLE IF NOT EXISTS usuarios (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(80) NOT NULL,
 correo VARCHAR(120) NOT NULL UNIQUE,
 clave VARCHAR(255) NOT NULL,
 role VARCHAR(20) NOT NULL DEFAULT 'cliente',
 codigo_recuperacion VARCHAR(20),
 codigo_expiracion DATETIME,
 categorias_personalizadas VARCHAR(5000)
);

CREATE TABLE IF NOT EXISTS saldos (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT NOT NULL UNIQUE,
 saldo_inicial DECIMAL(12,2) NOT NULL DEFAULT 0,
 saldo_actual DECIMAL(12,2) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 CONSTRAINT fk_saldos_user FOREIGN KEY(user_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS gastos (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT NOT NULL,
 categoria VARCHAR(60) NOT NULL,
 tipo_movimiento VARCHAR(20) NOT NULL DEFAULT 'GASTO',
 tipo_gasto VARCHAR(20) NOT NULL DEFAULT 'PREDEFINIDO',
 medio_pago VARCHAR(50) NOT NULL,
 descripcion VARCHAR(160) NOT NULL,
 valor DECIMAL(12,2) NOT NULL,
 recurrente BOOLEAN NOT NULL DEFAULT FALSE,
 created_at DATETIME NOT NULL,
 updated_at DATETIME NOT NULL,
 CONSTRAINT fk_gastos_user FOREIGN KEY(user_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
-- La aplicación repara automáticamente las FK antiguas de saldos/gastos para que apunten a usuarios.
