package com.moneytrack.dto;

public class RegisterRequest {
    private String name;
    private String username;
    private String email;
    private String correo;
    private String password;
    private String role;
    private String rol;

    public RegisterRequest() {}

    public String getName() {
        return name != null ? name : nombre;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String nombre;

    public String getUsername() {
        // Si username viene vacío pero hay correo, usamos el correo como username automáticamente
        if (username == null || username.isBlank()) {
            if (email != null) return email;
            if (correo != null) return correo;
        }
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email != null ? email : correo;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCorreo() {
        return correo != null ? correo : email;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassword() {
        return password != null ? password : clave;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String clave;

    public String getNombre() {
        return getName();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return getPassword();
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getRole() {
        return "cliente";
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getRol() {
        return "cliente";
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
}
