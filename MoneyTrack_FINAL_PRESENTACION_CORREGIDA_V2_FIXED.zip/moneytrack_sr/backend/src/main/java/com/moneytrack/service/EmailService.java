package com.moneytrack.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:}")
    private String remitente;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void enviarConfirmacionRegistro(String destino, String nombre) {
        String saludo = nombre == null || nombre.isBlank() ? "Hola" : "Hola " + nombre.trim();
        enviar(destino, "Cuenta creada en Money Track",
                saludo + ",\n\nTu cuenta fue creada correctamente. Ya puedes iniciar sesion en Money Track.\n\n"
                        + "Si no solicitaste esta cuenta, puedes ignorar este mensaje.");
    }

    public void enviarCodigoRecuperacion(String destino, String codigo) {
        enviar(destino, "Codigo de recuperacion Money Track",
                "Tu codigo de recuperacion es: " + codigo + "\n\n"
                        + "El codigo vence en 15 minutos. Si no solicitaste este cambio, ignora este correo.");
    }

    private void enviar(String destino, String asunto, String cuerpo) {
        SimpleMailMessage mensaje = new SimpleMailMessage();
        if (remitente != null && !remitente.isBlank() && !remitente.startsWith("tu_correo")) {
            mensaje.setFrom(remitente);
        }
        mensaje.setTo(destino);
        mensaje.setSubject(asunto);
        mensaje.setText(cuerpo);
        mailSender.send(mensaje);
    }
}
