package com.moneytrack.service;

import com.moneytrack.dto.*;
import com.moneytrack.entity.*;
import com.moneytrack.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.text.Normalizer;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MoneyTrackService {
    private final UserRepository users;
    private final SaldoRepository saldos;
    private final GastoRepository gastos;
    private final EmailService emailService;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    private static final List<String> PREDEFINIDAS = List.of(
        "Mercado","Transporte","Salud","Educación","Servicios","Vivienda",
        "Alimentación","Entretenimiento","Ropa","Tecnología","Mascotas","Otro"
    );
    private static final List<String> FIJAS = List.of(
        "Arriendo","Servicios públicos","Internet","Telefonía","Suscripciones",
        "Cuota de crédito","Seguros","Mensualidades app","Colegio/Universidad","Otro fijo"
    );
    private static final List<String> INUSUALES = List.of(
        "Reparaciones","Emergencias","Regalos","Multas","Viajes",
        "Compras extraordinarias","Mantenimiento","Otro inusual"
    );
    private static final List<String> INGRESOS = List.of(
        "Salario","Mesada","Freelance","Venta","Bono","Otros ingresos"
    );

    public MoneyTrackService(UserRepository u,SaldoRepository s,GastoRepository g,EmailService e){
        users=u;saldos=s;gastos=g;emailService=e;
    }

    private User user(Long id){
        return users.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Usuario no encontrado."));
    }

    private void checkRole(String role){
        if(role==null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"El rol es obligatorio.");
        String r=role.trim().toLowerCase();
        if(!r.equals("admin")&&!r.equals("administrador")&&!r.equals("cliente")&&!r.equals("user"))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Rol inválido.");
    }

    public LoginResponse register(RegisterRequest r){
        String correo=r.getUsername();
        if(correo==null||correo.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"El correo es obligatorio.");
        if(users.existsByUsername(correo)) throw new ResponseStatusException(HttpStatus.CONFLICT,"El usuario ya existe.");
        var u=new User(r.getName(),correo,encoder.encode(r.getPassword()),"cliente");
        u=users.save(u);
        emailService.enviarConfirmacionRegistro(u.getUsername(),u.getName());
        return new LoginResponse(u.getId(),u.getName(),u.getUsername(),u.getRole());
    }

    @Transactional public void forgotPassword(ForgotPasswordRequest r){
        var u=users.findByUsername(r.getEmail()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"No existe una cuenta con ese correo."));
        String codigo=String.format("%06d",new Random().nextInt(1_000_000));
        u.setCodigoRecuperacion(codigo);u.setCodigoExpiracion(LocalDateTime.now().plusMinutes(15));users.save(u);
        emailService.enviarCodigoRecuperacion(u.getUsername(),codigo);
    }

    @Transactional public void resetPassword(ResetPasswordRequest r){
        var u=users.findByUsername(r.getEmail()).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"No existe una cuenta con ese correo."));
        if(u.getCodigoRecuperacion()==null||!u.getCodigoRecuperacion().equals(r.getToken()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Código inválido.");
        if(u.getCodigoExpiracion()==null||u.getCodigoExpiracion().isBefore(LocalDateTime.now()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"El código expiró. Solicita uno nuevo.");
        u.setPassword(encoder.encode(r.getNewPassword()));u.setCodigoRecuperacion(null);u.setCodigoExpiracion(null);users.save(u);
    }

    public LoginResponse login(LoginRequest r){
        var u=users.findByUsername(r.getEmail()).orElse(null);
        if(u==null||!encoder.matches(r.getPassword(),u.getPassword()))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Usuario o clave incorrectos.");
        return new LoginResponse(u.getId(),u.getName(),u.getUsername(),u.getRole());
    }

    private List<String> custom(User u,String tipo){
        if(u.getCategoriasPersonalizadas()==null||u.getCategoriasPersonalizadas().isBlank()) return new ArrayList<>();
        return Arrays.stream(u.getCategoriasPersonalizadas().split("\\|"))
            .map(x->x.split("::",2))
            .filter(a->a.length==2&&a[0].equals(tipo)).map(a->a[1])
            .filter(x->!x.isBlank()).distinct().collect(Collectors.toCollection(ArrayList::new));
    }

    private void addCustom(User u,String tipo,String nombre){
        String n=nombre.trim().replace("|","").replace("::","");
        if(n.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"La categoría no puede estar vacía.");
        List<String> c=custom(u,tipo);
        if(c.stream().anyMatch(x->x.equalsIgnoreCase(n))) return;
        String raw=u.getCategoriasPersonalizadas();
        String item=tipo+"::"+n;
        u.setCategoriasPersonalizadas(raw==null||raw.isBlank()?item:raw+"|"+item);
        users.save(u);
    }

    @Transactional public Map<String,Object> addCategoria(Long userId,String role,String tipo,String nombre){
        if(!"admin".equalsIgnoreCase(role)) userId=userId;
        User u=user(userId);
        String t=tipo==null?"PREDEFINIDO":tipo.toUpperCase();
        if(!Set.of("PREDEFINIDO","FIJO","INUSUAL","INGRESO").contains(t))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Tipo de categoría inválido.");
        addCustom(u,t,nombre);
        return categorias(u.getId());
    }

    @Transactional public void deleteCategoria(Long userId,String role,String tipo,String nombre){
        User u=user(userId);
        String raw=u.getCategoriasPersonalizadas();
        if(raw==null) return;
        String target=tipo.toUpperCase()+"::"+nombre;
        u.setCategoriasPersonalizadas(Arrays.stream(raw.split("\\|")).filter(x->!x.equalsIgnoreCase(target)).collect(Collectors.joining("|")));
        users.save(u);
    }

    public Map<String,Object> categorias(Long userId){
        User u=user(userId);
        return Map.of(
            "predefinidas",merge(PREDEFINIDAS,custom(u,"PREDEFINIDO")),
            "fijas",merge(FIJAS,custom(u,"FIJO")),
            "inusuales",merge(INUSUALES,custom(u,"INUSUAL")),
            "ingresos",merge(INGRESOS,custom(u,"INGRESO"))
        );
    }

    private List<String> merge(List<String>a,List<String>b){
        ArrayList<String> out=new ArrayList<>(a);b.forEach(x->{if(out.stream().noneMatch(y->y.equalsIgnoreCase(x)))out.add(x);});return out;
    }

    @Transactional
    public DashboardResponse dashboard(Long userId,String role){
        User me=user(userId); boolean admin="admin".equalsIgnoreCase(role);
        List<User> us=users.findAllByOrderByNameAsc();
        for(User u:us) applyRecurring(u);
        List<Saldo> ss=admin?saldos.findAllByOrderByIdAsc():saldos.findByUserId(userId).map(List::of).orElse(List.of());
        List<Gasto> gs=admin?gastos.findAllByOrderByCreatedAtDesc():gastos.findByUserIdOrderByCreatedAtDesc(userId);
        ArrayList<DashboardResponse.Reporte> reps=new ArrayList<>();
        var now=LocalDateTime.now();var cur=now.withDayOfMonth(1).with(LocalTime.MIN);var prevStart=cur.minusMonths(1);var prevEnd=cur.minusNanos(1);
        for(User u:admin?us:List.of(me)){
            BigDecimal a=gastos.sumCurrent(u.getId(),cur),b=gastos.sumPrevious(u.getId(),prevStart,prevEnd);
            reps.add(new DashboardResponse.Reporte(u.getId(),u.getName(),a==null?BigDecimal.ZERO:a,b==null?BigDecimal.ZERO:b));
        }
        Map<String,Object> c=categorias(userId);
        return new DashboardResponse(admin,us,ss,gs,reps,
            new DashboardResponse.Categorias((List<String>)c.get("predefinidas"),(List<String>)c.get("fijas"),(List<String>)c.get("inusuales"),(List<String>)c.get("ingresos")));
    }

    private void applyRecurring(User u){
        var all=gastos.findByUserIdOrderByCreatedAtDesc(u.getId());
        var start=LocalDateTime.now().withDayOfMonth(1).with(LocalTime.MIN);
        var end=start.plusMonths(1);
        Set<String> current=all.stream().filter(g->g.getCreatedAt()!=null&&!g.getCreatedAt().isBefore(start)&&g.getCreatedAt().isBefore(end))
            .map(g->g.getCategoria()+"|"+g.getDescripcion().replace(" (recurrente)","")).collect(Collectors.toSet());
        all.stream().filter(g->g.isRecurrente()&&"GASTO".equals(g.getTipoMovimiento())&&"FIJO".equals(g.getTipoGasto()))
            .forEach(g->{String key=g.getCategoria()+"|"+g.getDescripcion().replace(" (recurrente)",""); if(!current.contains(key)){
                Gasto n=new Gasto();n.setUser(u);n.setCategoria(g.getCategoria());n.setTipoMovimiento("GASTO");n.setTipoGasto("FIJO");n.setMedioPago(g.getMedioPago());n.setDescripcion(g.getDescripcion().contains("(recurrente)")?g.getDescripcion():g.getDescripcion()+" (recurrente)");n.setValor(g.getValor());n.setRecurrente(true);
                var s=saldos.findByUserId(u.getId()).orElse(null);
                if(s!=null&&s.getSaldoActual().compareTo(n.getValor())>=0){gastos.save(n);s.setSaldoActual(s.getSaldoActual().subtract(n.getValor()));saldos.save(s);}
            }});
    }

    @Transactional public void saveSaldo(SaldoRequest r,Long sessionUser,String role){
        Long target="admin".equalsIgnoreCase(role)&&r.userId()!=null?r.userId():sessionUser;
        User u=user(target);
        Saldo s=saldos.findByUserId(target).orElseGet(Saldo::new);s.setUser(u);s.setSaldoInicial(r.saldo());s.setSaldoActual(r.saldo());saldos.save(s);
    }

    @Transactional public void saveGasto(GastoRequest r,Long sessionUser,String role){
        Long target="admin".equalsIgnoreCase(role)&&r.userId()!=null?r.userId():sessionUser;
        User u=user(target); String mov=norm(r.tipoMovimiento(),"GASTO"), tg=norm(r.tipoGasto(),"PREDEFINIDO");
        if(!Set.of("GASTO","INGRESO").contains(mov)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Tipo de movimiento inválido.");
        if(mov.equals("INGRESO")) tg="INGRESO";
        if(mov.equals("GASTO")&&!Set.of("PREDEFINIDO","FIJO","INUSUAL").contains(tg)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Tipo de gasto inválido.");
        Saldo s=saldos.findByUserId(target).orElseGet(()->{Saldo x=new Saldo();x.setUser(u);x.setSaldoInicial(BigDecimal.ZERO);x.setSaldoActual(BigDecimal.ZERO);return saldos.save(x);});
        Gasto g=new Gasto();g.setUser(u);g.setCategoria(r.categoria());g.setTipoMovimiento(mov);g.setTipoGasto(tg);g.setMedioPago(r.medioPago());g.setDescripcion(r.descripcion());g.setValor(r.valor());g.setRecurrente(Boolean.TRUE.equals(r.recurrente())&&tg.equals("FIJO")&&mov.equals("GASTO"));gastos.save(g);
        s.setSaldoActual(mov.equals("INGRESO")?s.getSaldoActual().add(r.valor()):s.getSaldoActual().subtract(r.valor()));
        if(s.getSaldoActual().compareTo(BigDecimal.ZERO)<0){gastos.delete(g);throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No hay saldo suficiente.");}
        saldos.save(s);
    }

    private String norm(String v,String def){return v==null||v.isBlank()?def:v.trim().toUpperCase();}

    private Gasto editable(Long id,Long uid,String role){
        Gasto g=gastos.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Movimiento no encontrado."));
        if(!"admin".equalsIgnoreCase(role)&&!g.getUser().getId().equals(uid)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"No tienes permiso para modificar este movimiento.");
        return g;
    }

    @Transactional public void updateGasto(Long id,GastoRequest r,Long uid,String role){
        Gasto g=editable(id,uid,role);Saldo s=saldos.findByUserId(g.getUser().getId()).orElseThrow(()->new ResponseStatusException(HttpStatus.BAD_REQUEST,"Saldo no encontrado."));
        BigDecimal oldEffect="INGRESO".equals(g.getTipoMovimiento())?g.getValor().negate():g.getValor();
        BigDecimal newEffect="INGRESO".equals(norm(r.tipoMovimiento(),g.getTipoMovimiento()))?r.valor().negate():r.valor();
        BigDecimal delta=newEffect.subtract(oldEffect);
        if(s.getSaldoActual().subtract(delta).compareTo(BigDecimal.ZERO)<0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No hay saldo suficiente.");
        g.setCategoria(r.categoria());g.setTipoMovimiento(norm(r.tipoMovimiento(),g.getTipoMovimiento()));g.setTipoGasto(g.getTipoMovimiento().equals("INGRESO")?"INGRESO":norm(r.tipoGasto(),g.getTipoGasto()));g.setMedioPago(r.medioPago());g.setDescripcion(r.descripcion());g.setValor(r.valor());g.setRecurrente(Boolean.TRUE.equals(r.recurrente())&&g.getTipoGasto().equals("FIJO")&&g.getTipoMovimiento().equals("GASTO"));gastos.save(g);
        s.setSaldoActual(s.getSaldoActual().subtract(delta));saldos.save(s);
    }

    @Transactional public void deleteGasto(Long id,Long uid,String role){
        Gasto g=editable(id,uid,role);Saldo s=saldos.findByUserId(g.getUser().getId()).orElse(null);
        if(s!=null)s.setSaldoActual("INGRESO".equals(g.getTipoMovimiento())?s.getSaldoActual().subtract(g.getValor()):s.getSaldoActual().add(g.getValor()));
        gastos.delete(g);if(s!=null)saldos.save(s);
    }

    @Transactional public void updateUser(Long id,UserUpdateRequest r,Long uid,String role){
        if(!"admin".equalsIgnoreCase(role))throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Acceso de administrador requerido.");
        User u=user(id);
        if(users.findByUsername(r.username()).filter(x->!x.getId().equals(id)).isPresent())throw new ResponseStatusException(HttpStatus.CONFLICT,"El usuario ya existe.");
        checkRole(r.role());u.setName(r.name());u.setUsername(r.username());u.setRole(r.role());
        if(r.password()!=null&&!r.password().isBlank())u.setPassword(encoder.encode(r.password()));users.save(u);
    }

    @Transactional public void deleteUser(Long id,Long uid,String role){
        if(!"admin".equalsIgnoreCase(role))throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Acceso de administrador requerido.");
        if(id.equals(uid))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"No puedes eliminar tu propia cuenta de administrador.");
        users.delete(user(id));
    }

    @Transactional(readOnly=true)
    public byte[] certificado(Long sessionUser,String role,Long targetUser,String month){
        Long uid="admin".equalsIgnoreCase(role)&&targetUser!=null?targetUser:sessionUser;
        User u=user(uid);
        YearMonth ym;
        try{ym=YearMonth.parse(month);}catch(Exception e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Mes inválido. Usa AAAA-MM.");}
        LocalDateTime start=ym.atDay(1).atStartOfDay(),end=ym.plusMonths(1).atDay(1).atStartOfDay();
        List<Gasto> ms=gastos.findByUserIdOrderByCreatedAtDesc(uid).stream().filter(g->g.getCreatedAt()!=null&&!g.getCreatedAt().isBefore(start)&&g.getCreatedAt().isBefore(end)).toList();
        BigDecimal ingresos=ms.stream().filter(g->"INGRESO".equals(g.getTipoMovimiento())).map(Gasto::getValor).reduce(BigDecimal.ZERO,BigDecimal::add);
        BigDecimal egresos=ms.stream().filter(g->"GASTO".equals(g.getTipoMovimiento())).map(Gasto::getValor).reduce(BigDecimal.ZERO,BigDecimal::add);
        StringBuilder body=new StringBuilder();
        body.append("MONEY TRACK - CERTIFICADO MENSUAL\n");
        body.append("Usuario: ").append(u.getName()).append("\n");
        body.append("Correo: ").append(u.getUsername()).append("\n");
        body.append("Periodo: ").append(ym.format(DateTimeFormatter.ofPattern("MMMM 'de' yyyy",new Locale("es","CO")))).append("\n\n");
        body.append("RESUMEN\nIngresos: ").append(moneyText(ingresos)).append("\nGastos: ").append(moneyText(egresos)).append("\nBalance del mes: ").append(moneyText(ingresos.subtract(egresos))).append("\n\n");
        body.append("MOVIMIENTOS\n");
        for(Gasto g:ms) body.append(g.getCreatedAt().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))).append(" | ").append(g.getTipoMovimiento()).append(" | ").append(g.getTipoGasto()).append(" | ").append(g.getCategoria()).append(" | ").append(moneyText(g.getValor())).append(" | ").append(g.getDescripcion()).append("\n");
        return simplePdf(body.toString(),u.getName(),ym);
    }

    private String moneyText(BigDecimal n){return "$ "+n.setScale(0,java.math.RoundingMode.HALF_UP).toPlainString();}

    private byte[] simplePdf(String text,String name,YearMonth ym){
        String[] raw=text.split("\\n",-1);List<String> lines=new ArrayList<>();
        for(String line:raw){String s=strip(line);while(s.length()>105){lines.add(s.substring(0,105));s=s.substring(105);}lines.add(s);}
        StringBuilder stream=new StringBuilder("BT\n/F1 9 Tf\n50 800 Td\n");
        int y=0;for(String line:lines){if(y>54){stream.append("0 -14 Td\n");}else if(y>0)stream.append("0 -14 Td\n");stream.append("(").append(pdfEscape(line)).append(") Tj\n");y++;if(y>54){stream.append("ET\n");break;}}stream.append("ET\n");
        byte[] content=stream.toString().getBytes(StandardCharsets.ISO_8859_1);
        StringBuilder pdf=new StringBuilder("%PDF-1.4\n");
        List<Integer> offs=new ArrayList<>();offs.add(0);
        addObj(pdf,offs,1,"<< /Type /Catalog /Pages 2 0 R >>");
        addObj(pdf,offs,2,"<< /Type /Pages /Kids [3 0 R] /Count 1 >>");
        addObj(pdf,offs,3,"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>");
        addObj(pdf,offs,4,"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
        addObj(pdf,offs,5,"<< /Length "+content.length+" >>\nstream\n"+new String(content,StandardCharsets.ISO_8859_1)+"endstream");
        int xref=pdf.length();pdf.append("xref\n0 6\n0000000000 65535 f \n");for(int i=1;i<6;i++)pdf.append(String.format("%010d 00000 n \n",offs.get(i)));pdf.append("trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n").append(xref).append("\n%%EOF");
        return pdf.toString().getBytes(StandardCharsets.ISO_8859_1);
    }
    private void addObj(StringBuilder p,List<Integer> o,int n,String body){o.add(p.length());p.append(n).append(" 0 obj\n").append(body).append("\nendobj\n");}
    private String pdfEscape(String s){return s.replace("\\","\\\\").replace("(","\\(").replace(")","\\)");}
    private String strip(String s){return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").replace("—","-").replace("€","EUR");}
}