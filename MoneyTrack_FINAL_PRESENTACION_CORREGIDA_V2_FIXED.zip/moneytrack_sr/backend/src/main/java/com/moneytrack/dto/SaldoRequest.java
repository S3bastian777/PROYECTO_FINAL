package com.moneytrack.dto;

import java.math.BigDecimal;

public class SaldoRequest {
    private BigDecimal saldo;
    private Long userId;

    public SaldoRequest() {}

    public SaldoRequest(BigDecimal saldo, Long userId) {
        this.saldo = saldo;
        this.userId = userId;
    }

    // Métodos estilo record (para que el servicio no falle)
    public BigDecimal saldo() {
        return saldo;
    }

    public Long userId() {
        return userId;
    }

    // Métodos tradicionales por si acaso
    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}