package com.moneytrack.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="gastos")
public class Gasto {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;

    @JsonIgnore
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="user_id", nullable=false)
    private User user;

    @Column(nullable=false,length=60) private String categoria;
    @Column(name="tipo_movimiento",nullable=false,length=20) private String tipoMovimiento = "GASTO";
    @Column(name="tipo_gasto",nullable=false,length=20) private String tipoGasto = "PREDEFINIDO";
    @Column(name="medio_pago",nullable=false,length=50) private String medioPago = "Efectivo";
    @Column(nullable=false,length=160) private String descripcion;
    @Column(nullable=false,precision=12,scale=2) private BigDecimal valor;
    @Column(nullable=false) private boolean recurrente = false;
    @Column(name="created_at",nullable=false) private LocalDateTime createdAt;
    @Column(name="updated_at",nullable=false) private LocalDateTime updatedAt;

    @PrePersist void prePersist(){ var now=LocalDateTime.now(); createdAt=now; updatedAt=now; }
    @PreUpdate void preUpdate(){ updatedAt=LocalDateTime.now(); }

    public Long getId(){return id;}
    public User getUser(){return user;} public void setUser(User user){this.user=user;}
    public String getCategoria(){return categoria;} public void setCategoria(String v){categoria=v;}
    public String getTipoMovimiento(){return tipoMovimiento;} public void setTipoMovimiento(String v){tipoMovimiento=v;}
    public String getTipoGasto(){return tipoGasto;} public void setTipoGasto(String v){tipoGasto=v;}
    public String getMedioPago(){return medioPago;} public void setMedioPago(String v){medioPago=v;}
    public String getDescripcion(){return descripcion;} public void setDescripcion(String v){descripcion=v;}
    public BigDecimal getValor(){return valor;} public void setValor(BigDecimal v){valor=v;}
    public boolean isRecurrente(){return recurrente;} public void setRecurrente(boolean v){recurrente=v;}
    public Long getUserId(){return user==null?null:user.getId();}
    public String getUserName(){return user==null?null:user.getName();}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public LocalDateTime getUpdatedAt(){return updatedAt;}
}