package com.moneytrack.dto;

import jakarta.validation.constraints.NotBlank;

public class ResetPasswordRequest {

    @NotBlank
    private String email;

    @NotBlank
    private String token;

    @NotBlank
    private String newPassword;

    public ResetPasswordRequest() {}

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getCode() { return token; }
    public void setCode(String code) { this.token = code; }

    public String getCodigo() { return token; }
    public void setCodigo(String codigo) { this.token = codigo; }

    public String getNewPassword() { return newPassword; }
    public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
}
