package com.moneytrack.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record GastoRequest(
    Long userId,
    @NotNull @DecimalMin("1.0") BigDecimal valor,
    @NotBlank @Size(max=60) String categoria,
    @NotBlank @Size(max=50) String medioPago,
    @NotBlank @Size(max=160) String descripcion,
    String tipoMovimiento,
    String tipoGasto,
    Boolean recurrente
) {}