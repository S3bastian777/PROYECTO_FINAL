package com.moneytrack.repository;

import com.moneytrack.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    // Cambiado 'Username' por 'Correo' que es el atributo real en User.java
    Optional<User> findByCorreo(String correo);
    boolean existsByCorreo(String correo);

    // Alias para mantener compatibilidad con llamados en inglés si los hay
    default Optional<User> findByUsername(String username) {
        return findByCorreo(username);
    }
    
    default boolean existsByUsername(String username) {
        return existsByCorreo(username);
    }

    List<User> findAllByOrderByNombreAsc();
    
    default List<User> findAllByOrderByNameAsc() {
        return findAllByOrderByNombreAsc();
    }
}