package com.moneytrack.controller;

import com.moneytrack.dto.*;
import com.moneytrack.service.MoneyTrackService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="*")
public class MoneyTrackController {
    private final MoneyTrackService service;
    public MoneyTrackController(MoneyTrackService service){this.service=service;}

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardResponse> dashboard(@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        return ResponseEntity.ok(service.dashboard(userId,role));
    }

    @GetMapping("/categorias")
    public ResponseEntity<Map<String,Object>> categorias(@RequestHeader("X-User-Id") Long userId){
        return ResponseEntity.ok(service.categorias(userId));
    }

    @PostMapping("/categorias")
    public ResponseEntity<Map<String,Object>> addCategoria(@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role,@RequestBody Map<String,String> body){
        return ResponseEntity.ok(service.addCategoria(userId,role,body.get("tipo"),body.get("nombre")));
    }

    @DeleteMapping("/categorias")
    public ResponseEntity<Void> deleteCategoria(@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role,@RequestParam String tipo,@RequestParam String nombre){
        service.deleteCategoria(userId,role,tipo,nombre);return ResponseEntity.noContent().build();
    }

    @PostMapping("/saldos")
    public ResponseEntity<Void> saveSaldo(@Valid @RequestBody SaldoRequest request,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.saveSaldo(request,userId,role);return ResponseEntity.ok().build();
    }

    @PostMapping("/gastos")
    public ResponseEntity<Void> saveGasto(@Valid @RequestBody GastoRequest request,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.saveGasto(request,userId,role);return ResponseEntity.ok().build();
    }

    @PutMapping("/gastos/{id}")
    public ResponseEntity<Void> updateGasto(@PathVariable Long id,@Valid @RequestBody GastoRequest request,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.updateGasto(id,request,userId,role);return ResponseEntity.ok().build();
    }

    @DeleteMapping("/gastos/{id}")
    public ResponseEntity<Void> deleteGasto(@PathVariable Long id,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.deleteGasto(id,userId,role);return ResponseEntity.ok().build();
    }

    @GetMapping("/reportes/certificado")
    public ResponseEntity<byte[]> certificado(@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role,@RequestParam String month,@RequestParam(required=false) Long targetUser){
        byte[] pdf=service.certificado(userId,role,targetUser,month);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_PDF)
            .header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=moneytrack-"+month+".pdf").body(pdf);
    }

    @PutMapping("/admin/usuarios/{id}")
    public ResponseEntity<Void> updateUser(@PathVariable Long id,@Valid @RequestBody UserUpdateRequest request,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.updateUser(id,request,userId,role);return ResponseEntity.ok().build();
    }

    @DeleteMapping("/admin/usuarios/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.deleteUser(id,userId,role);return ResponseEntity.ok().build();
    }

    // Rutas antiguas mantenidas para compatibilidad con la entrega anterior.
    @PutMapping("/users/{id}")
    public ResponseEntity<Void> updateUserLegacy(@PathVariable Long id,@Valid @RequestBody UserUpdateRequest request,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.updateUser(id,request,userId,role);return ResponseEntity.ok().build();
    }
    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUserLegacy(@PathVariable Long id,@RequestHeader("X-User-Id") Long userId,@RequestHeader("X-User-Role") String role){
        service.deleteUser(id,userId,role);return ResponseEntity.ok().build();
    }
}