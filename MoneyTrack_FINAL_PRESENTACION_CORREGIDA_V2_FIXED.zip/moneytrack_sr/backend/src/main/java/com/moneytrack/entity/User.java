package com.moneytrack.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.time.LocalDateTime;

@Entity
@Table(name = "usuarios")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name="nombre", nullable=false, length=80) private String nombre;
    @Column(name="correo", unique=true, nullable=false, length=120) private String correo;
    @Column(name="clave", nullable=false, length=255) private String clave;
    @Column(name="role", nullable=false, length=20) private String role = "cliente";
    @Column(name="codigo_recuperacion") @JsonIgnore private String codigoRecuperacion;
    @Column(name="codigo_expiracion") @JsonIgnore private LocalDateTime codigoExpiracion;
    @Column(name="categorias_personalizadas", length=5000) @JsonIgnore private String categoriasPersonalizadas;

    public User() {}
    public User(String nombre,String correo,String clave,String role){this.nombre=nombre;this.correo=correo;this.clave=clave;this.role=role;}

    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
    public String getCorreo(){return correo;} public void setCorreo(String v){correo=v;}
    @JsonIgnore public String getClave(){return clave;} public void setClave(String v){clave=v;}
    public String getRole(){return role;} public void setRole(String v){role=v;}
    @JsonIgnore public String getCodigoRecuperacion(){return codigoRecuperacion;} public void setCodigoRecuperacion(String v){codigoRecuperacion=v;}
    @JsonIgnore public LocalDateTime getCodigoExpiracion(){return codigoExpiracion;} public void setCodigoExpiracion(LocalDateTime v){codigoExpiracion=v;}
    @JsonIgnore public String getCategoriasPersonalizadas(){return categoriasPersonalizadas;} public void setCategoriasPersonalizadas(String v){categoriasPersonalizadas=v;}

    public String getName(){return nombre;} public void setName(String v){nombre=v;}
    public String getUsername(){return correo;} public void setUsername(String v){correo=v;}
    @JsonIgnore public String getPassword(){return clave;} public void setPassword(String v){clave=v;}
}