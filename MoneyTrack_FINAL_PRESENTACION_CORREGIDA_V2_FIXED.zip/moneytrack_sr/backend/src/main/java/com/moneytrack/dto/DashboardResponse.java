package com.moneytrack.dto;

import com.moneytrack.entity.*;
import java.util.*;

public record DashboardResponse(
    boolean admin,
    List<User> usuarios,
    List<Saldo> saldos,
    List<Gasto> gastos,
    List<Reporte> reportes,
    Categorias categorias
) {
    public record Reporte(Long userId,String nombre,java.math.BigDecimal mesActual,java.math.BigDecimal mesPasado) {}
    public record Categorias(List<String> predefinidas,List<String> fijas,List<String> inusuales,List<String> ingresos) {}
}