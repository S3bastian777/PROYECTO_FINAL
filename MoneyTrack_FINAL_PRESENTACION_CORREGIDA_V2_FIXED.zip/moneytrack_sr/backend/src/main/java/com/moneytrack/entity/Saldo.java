package com.moneytrack.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="saldos", uniqueConstraints = @UniqueConstraint(columnNames = "user_id"))
public class Saldo {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @JsonIgnore @OneToOne @JoinColumn(name="user_id", nullable=false, unique=true) private User user;
 @Column(name="saldo_inicial", nullable=false, precision=12, scale=2) private BigDecimal saldoInicial=BigDecimal.ZERO;
 @Column(name="saldo_actual", nullable=false, precision=12, scale=2) private BigDecimal saldoActual=BigDecimal.ZERO;
 @Column(name="created_at", nullable=false) private LocalDateTime createdAt;
 @Column(name="updated_at", nullable=false) private LocalDateTime updatedAt;
 @PrePersist void prePersist(){var now=LocalDateTime.now();createdAt=now;updatedAt=now;}
 @PreUpdate void preUpdate(){updatedAt=LocalDateTime.now();}
 public Long getId(){return id;} public User getUser(){return user;} public void setUser(User user){this.user=user;}
 public BigDecimal getSaldoInicial(){return saldoInicial;} public void setSaldoInicial(BigDecimal v){saldoInicial=v;}
 public BigDecimal getSaldoActual(){return saldoActual;} public void setSaldoActual(BigDecimal v){saldoActual=v;}
 public Long getUserId(){return user==null?null:user.getId();} public String getUserName(){return user==null?null:user.getName();}
 public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
