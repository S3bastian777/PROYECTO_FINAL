package com.moneytrack.service;
import com.moneytrack.entity.User; import com.moneytrack.repository.UserRepository; import org.springframework.boot.CommandLineRunner; import org.springframework.jdbc.core.JdbcTemplate; import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.stereotype.Component;
@Component public class DataInitializer implements CommandLineRunner { private final UserRepository users; private final JdbcTemplate jdbc; private final BCryptPasswordEncoder enc=new BCryptPasswordEncoder(); public DataInitializer(UserRepository u,JdbcTemplate j){users=u;jdbc=j;} public void run(String... a){repairForeignKeys(); if(!users.existsByUsername("admin"))users.save(new User("Administrador","admin",enc.encode("123456"),"admin"));if(!users.existsByUsername("usuario"))users.save(new User("Usuario Demo","usuario",enc.encode("123456"),"cliente"));}
 private void repairForeignKeys(){
   migrateLegacyUsers();
   try{jdbc.execute("ALTER TABLE saldos DROP FOREIGN KEY fk_saldos_user");}catch(Exception ignored){}
   try{jdbc.execute("ALTER TABLE gastos DROP FOREIGN KEY fk_gastos_user");}catch(Exception ignored){}
   try{jdbc.execute("ALTER TABLE saldos ADD CONSTRAINT fk_saldos_user FOREIGN KEY (user_id) REFERENCES usuarios(id) ON DELETE CASCADE");}catch(Exception ignored){}
   try{jdbc.execute("ALTER TABLE gastos ADD CONSTRAINT fk_gastos_user FOREIGN KEY (user_id) REFERENCES usuarios(id) ON DELETE CASCADE");}catch(Exception ignored){}
 }
 private void migrateLegacyUsers(){
   try{jdbc.execute("INSERT IGNORE INTO usuarios (id,nombre,correo,clave,role) SELECT id,name,username,password,role FROM users");}catch(Exception ignored){}
 }
 }
