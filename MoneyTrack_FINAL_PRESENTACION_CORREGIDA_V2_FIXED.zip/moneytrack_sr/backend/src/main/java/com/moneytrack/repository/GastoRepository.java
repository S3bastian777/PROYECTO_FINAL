package com.moneytrack.repository;

import com.moneytrack.entity.Gasto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface GastoRepository extends JpaRepository<Gasto, Long> {
    List<Gasto> findAllByOrderByCreatedAtDesc();
    @Query("SELECT g FROM Gasto g WHERE g.user.id = :userId ORDER BY g.createdAt DESC")
    List<Gasto> findByUserIdOrderByCreatedAtDesc(@Param("userId") Long userId);
    @Query("select coalesce(sum(g.valor),0) from Gasto g where g.user.id=:userId and g.tipoMovimiento='GASTO' and g.createdAt>=:start")
    BigDecimal sumCurrent(@Param("userId") Long userId,@Param("start") LocalDateTime start);
    @Query("select coalesce(sum(g.valor),0) from Gasto g where g.user.id=:userId and g.tipoMovimiento='GASTO' and g.createdAt between :start and :end")
    BigDecimal sumPrevious(@Param("userId") Long userId,@Param("start") LocalDateTime start,@Param("end") LocalDateTime end);
}