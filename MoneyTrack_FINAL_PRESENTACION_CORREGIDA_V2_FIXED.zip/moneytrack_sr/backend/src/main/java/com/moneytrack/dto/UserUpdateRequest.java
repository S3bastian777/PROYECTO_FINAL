package com.moneytrack.dto;

public class UserUpdateRequest {
    private String name;
    private String username;
    private String password;
    private String role;

    public UserUpdateRequest() {}

    public UserUpdateRequest(String name, String username, String password, String role) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String name() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String username() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String password() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String role() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}