package com.moneytrack.repository;

import com.moneytrack.entity.Saldo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SaldoRepository extends JpaRepository<Saldo, Long> {

    @Query("SELECT s FROM Saldo s WHERE s.user.id = :userId")
    Optional<Saldo> findByUserId(@Param("userId") Long userId);

    List<Saldo> findAllByOrderByIdAsc();
}