# Money Track — Spring Boot + React

Aplicación de control financiero personal con frontend React y backend Spring Boot + MySQL. La entrega conserva el esquema original de carpetas y archivos y amplía la funcionalidad sin crear nuevos archivos de aplicación.

## Funciones

- Login, registro y recuperación de contraseña por código enviado al correo.
- Roles administrador / cliente.
- Saldo disponible y saldo base.
- Registro de ingresos.
- Registro de gastos generales/predefinidos.
- Gastos fijos y gastos inusuales como divisiones independientes.
- Categorías personalizadas guardadas por usuario.
- Categorías recurrentes: un gasto fijo puede marcarse como recurrente y Money Track intenta generarlo cada mes cuando existe saldo suficiente.
- Edición y eliminación de movimientos con actualización automática del saldo.
- Metas de ahorro con progreso, aportes e imagen.
- Reporte mensual con ingresos, gastos generales, fijos e inusuales.
- Comparativo contra el mes anterior.
- Descarga de certificado mensual en PDF con ingresos, gastos, categorías, fechas y balance.
- Panel de administración de usuarios.
- Diseño responsive y renovado, inspirado en dashboards financieros modernos.

## Credenciales de prueba

- admin / 123456
- usuario / 123456

## Estructura conservada

- `backend/` — Spring Boot + JPA + MySQL
- `client/` — React
- `schema.sql` — estructura de MySQL

No se agregaron archivos JavaScript, Java o componentes nuevos fuera del esquema original; las mejoras se integraron sobre los archivos existentes.

## Ejecución

### 1. Base de datos

Ejecuta `backend/schema.sql` en MySQL Workbench, phpMyAdmin o consola MySQL.

Si tu instalación de MySQL tiene contraseña para `root`, modifica `backend/src/main/resources/application.properties`.

### 2. Backend

En una terminal:

```text
cd backend
mvn spring-boot:run
```

Backend: `http://localhost:8080`

También está incluido el Maven Wrapper original:

```text
bash mvnw spring-boot:run
```

### 3. Frontend

En otra terminal:

```text
cd client
npm install
npm start
```

Frontend: `http://localhost:3000`

## Flujo recomendado para sustentar

1. Iniciar sesión como cliente.
2. Registrar saldo base.
3. Registrar un ingreso.
4. Registrar un gasto general, uno fijo y uno inusual.
5. Crear una categoría personalizada, por ejemplo `Mensualidades app`, dentro de `Gastos fijos`.
6. Registrar una mensualidad y marcarla como recurrente.
7. Revisar el historial y el saldo.
8. Entrar a Reportes, elegir mes y descargar el certificado PDF.
9. Entrar como admin para demostrar administración de usuarios y reportes por usuario.

## Nota

El archivo SQL nuevo está alineado con las entidades actuales (`usuarios`, `gastos`, `saldos`). Si ya existe una base creada con una versión anterior del proyecto, es recomendable respaldarla y ejecutar el esquema actualizado antes de la sustentación.
